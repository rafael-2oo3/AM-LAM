package com.example.calculadorapilha;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import java.util.Stack;




public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    Stack<Integer> stack1 = new Stack<Integer>();
    int n1,n2,i;
    int resultado, tamanho;

    public void empilhar(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        EditText objvalor = (EditText) findViewById(R.id.valor);
        String valor = objvalor.getText().toString();
        resultado = Integer.parseInt(valor);
        stack1.push(resultado);
        objvalor.setText("");
        objvalor3.setText(stack1 + "");
    }

    public void desempilhar(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        stack1.pop();
        objvalor3.setText(stack1 + "");
    }

    public void soma(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        n1 = (Integer) stack1.pop();
        n2 = (Integer) stack1.pop();
        resultado = n1+n2;
        stack1.push(resultado);
        objvalor3.setText(stack1 + "");
    }

    public void subtracao(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        n1 = (Integer) stack1.pop();
        n2 = (Integer) stack1.pop();
        resultado = n1-n2;
        stack1.push(resultado);
        objvalor3.setText(stack1 + "");
    }

    public void multiplicacao(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        n1 = (Integer) stack1.pop();
        n2 = (Integer) stack1.pop();
        resultado = n1*n2;
        stack1.push(resultado);
        objvalor3.setText(stack1 + "");
    }

    public void divisao(View v){
        EditText objvalor3 = (EditText) findViewById(R.id.valor3);
        n1 = (Integer) stack1.pop();
        n2 = (Integer) stack1.pop();
        resultado = n1/n2;
        stack1.push(resultado);
        objvalor3.setText(stack1 + "");
    }


}